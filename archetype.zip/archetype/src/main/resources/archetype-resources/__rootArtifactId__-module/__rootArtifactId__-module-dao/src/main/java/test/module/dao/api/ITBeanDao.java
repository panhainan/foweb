#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * 
 */
package ${package}.test.module.dao.api;

import ${package}.foweb.module.dao.api.IBaseDao;
import ${package}.test.module.model.pojo.TBean;

/**
 * @author fireoct
 * @email panhainan@yeah.net
 * @date 2016-09-07
 */

public interface ITBeanDao extends IBaseDao<TBean> {

}
