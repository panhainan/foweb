#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.test.module.model.vo;

import ${package}.test.module.model.pojo.TBean;

public class TBeanVo extends TBean {

}
