#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
/**
 * 
 */
package ${package}.test.module.service.api;

import ${package}.foweb.module.service.api.IBaseService;
import ${package}.test.module.model.pojo.TBean;

/**
 * @author fireoct
 * @email panhainan@yeah.net
 * @date 2016-09-08
 */
public interface ITBeanService extends IBaseService<TBean> {

}
